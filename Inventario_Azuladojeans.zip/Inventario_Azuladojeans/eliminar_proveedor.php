<?php
  require_once("clases/confg.php");
  if(isset($_SESSION['backend_id'])){
    require_once("clases/proveedoresModulo.php");
    
    $proveedor=new Proveedores();
    $proveedor->eliminar_proveedor($_GET["id_proveedor"]);
    header("Location:".Conectar::ruta()."proveedores.php");
    exit();
  
  } else {
  	 header("Location:".Conectar::ruta()."index.php");
  	 exit();
  }
?>