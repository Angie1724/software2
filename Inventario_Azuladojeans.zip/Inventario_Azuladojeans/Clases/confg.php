<?php
  session_start();
   class Conectar{
        protected $dbh;
        protected function conexion(){
                 $conectar= $this->dbh= new PDO("mysql:local=127.0.0.1; dbname=inventario_Azuladojeans","root","");
        return $conectar;
       }
         public function set_names(){
         return $this->dbh->query("SET NAMES 'utf8'");
       }
      
        public function ruta(){
        return "http://localhost/inventario_Azuladojeans/";
        }
      }

      ?>
      
