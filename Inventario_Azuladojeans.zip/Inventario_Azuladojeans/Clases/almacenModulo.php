<?php
  class Almacen extends Conectar{
      public function get_almacen(){
         $conectar=parent::conexion();
         parent::set_names();
         $sql="select * from material_almacen;";
         $sql=$conectar->prepare($sql);
         $sql->execute();
         return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
      }
      public function agregar_almacen(){
          $conectar=parent::conexion();
          parent::set_names();
          if(empty($_POST["cod_producto"]) or empty($_POST["descripcion_producto"]) or empty($_POST["precio_producto"]) or empty($_POST["status_producto"]) or empty($_POST["existencia_producto"])or empty($_POST["ubicacion_producto"]) or empty($_POST["proveedor_producto"])){
             
             header("Location:".Conectar::ruta()."agregar_almacen.php?m=1");
             exit();
          }
          $sql="insert into material_almacen
          values(null,?,?,?,?,?,?,?,now());";
          $sql=$conectar->prepare($sql);
          $sql->bindValue(1,$_POST["cod_producto"]);
          $sql->bindValue(2,$_POST["descripcion_producto"]);
          $sql->bindValue(3,$_POST["precio_producto"]);
          $sql->bindValue(4,$_POST["existencia_producto"]);
          $sql->bindValue(5,$_POST["ubicacion_producto"]);
          $sql->bindValue(6,$_POST["status_producto"]); 
          $sql->bindValue(7,$_POST["proveedor_producto"]); 
          $sql->execute();
          $resultado=$sql->fetch(PDO::FETCH_ASSOC);
          header("Location:".Conectar::ruta()."agregar_almacen.php?m=2");
          exit();
      }
      public function get_almacen_por_id($id_almacen){
            $conectar=parent::conexion();
            parent::set_names();
           $sql="select * from material_almacen where id_material_almacen=?";
           $sql=$conectar->prepare($sql);
           $sql->bindValue(1, $id_almacen);
           $sql->execute();
           return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
      }
      public function editar_almacen(){
           $conectar=parent::conexion();
           parent::set_names();
           if(empty($_POST["cod_material"]) or empty($_POST["material"]) or empty($_POST["precio"]) or empty($_POST["existencia"]) or empty($_POST["ubicacion_deposito"])or empty($_POST["status_material"]) or empty($_POST["rif_proveedor"])){
             
             header("Location:".Conectar::ruta()."editar_almacen.php?id_almacen=".$_POST["id"]."&m=1");
             exit();


        }

          $sql="update material_almacen set 
          cod_material=?,
          material=?,
          precio=?,
          existencia=?,
          ubicacion_deposito=?,
          status_material=?;
          rif_proveedor=?;
          fecha_ingreso=now()
          where 
          id_material_almacen=?
          ";
          $sql=$conectar->prepare($sql);
          $sql->bindValue(1,$_POST["cod_material"]);
          $sql->bindValue(2,$_POST["material"]);
          $sql->bindValue(3,$_POST["precio"]);
          $sql->bindValue(4,$_POST["existencia"]);
          $sql->bindValue(5,$_POST["ubicacion_deposito"]);
          $sql->bindValue(6,$_POST["status_material"]);
          $sql->bindValue(7,$_POST["rif_proveedor"]);
          $sql->execute();
          $resultado=$sql->fetch(PDO::FETCH_ASSOC);
          header("Location:".Conectar::ruta()."editar_almacen.php?id_almacen=".$_POST["id"]."&m=2");
          exit();
      }
      public function eliminar_almacen($id_entrada){
          $conectar=parent::conexion();
          parent::set_names();
          $sql="delete from material_almacen where id_material_almacen=?";
          $sql=$conectar->prepare($sql);
          $sql->bindValue(1,$id_entrada);
          $sql->execute();
          return $resultado=$sql->fetch(PDO::FETCH_ASSOC);
      }
       public function get_orden_compras_por_fecha(){
        $conectar=parent::conexion();
        parent::set_names();
        $dia= $_POST["dia"];
        $mes= $_POST["mes"];
        $ano= $_POST["ano"];
        $dia1= $_POST["dia1"];
        $mes1= $_POST["mes1"];
        $ano1= $_POST["ano1"];
        $fecha_desde= ($ano."-".$mes."-".$dia);
        $fecha_hasta= ($ano1."-".$mes1."-".$dia1);
        $sql="select * from orden_compras where rif_proveedor=? and fecha_ingreso>=? and fecha_ingreso<=?;";
    
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1,$_POST["rif_proveedor"]);
        $sql->bindValue(2,$fecha_desde);
        $sql->bindValue(3,$fecha_hasta);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    } 
     public function get_cant_productos_por_fecha(){
        $conectar=parent::conexion();
        parent::set_names();
        $dia= $_POST["dia"];
        $mes= $_POST["mes"];
        $ano= $_POST["ano"];
        $dia1= $_POST["dia1"];
        $mes1= $_POST["mes1"];
        $ano1= $_POST["ano1"];
        $fecha_desde= ($ano."-".$mes."-".$dia);
        $fecha_hasta= ($ano1."-".$mes1."-".$dia1);
        $sql="select sum(cantidad) as total from orden_compras where rif_proveedor=? and fecha_ingreso >=? and fecha_ingreso <=?;";
    
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1,$_POST["rif_proveedor"]);
        $sql->bindValue(2,$fecha_desde);
        $sql->bindValue(3,$fecha_hasta);
        $sql->execute();
        return $resultado=$sql->fetch(PDO::FETCH_ASSOC);
    } 
  } 
?>