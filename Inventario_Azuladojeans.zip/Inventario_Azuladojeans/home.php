<?php
require_once("clases/confg.php");

if (isset($_SESSION['backend_id'])) {
  

?>

<!DOCTYPE html>
<html lang="en">
<head >
   <meta charset="UTF-8">
   <title>Azulado Jeans</title>
   <link rel="stylesheet"  href="">
  <link rel="icon"  href="imagenesazulado/pantalones.ico">
   <?php require_once("head.php");?>

</head>
<body>
     
     <div class="container-fluid">
      
      <?php require_once("menu_principal.php");?>

      <div class="container-fluid">
        <div class="inicio">
          <div class="row">
                <div class="col-sm-3">
                 
                 <?php require_once("menu_lateral.php");?>
                </div>

              <div class="col-sm-8">
                 
                 <h2>Sistema de control de inventarios y ventas</h2>
                 <p class="justify">“El trabajo va a ocupar gran parte de tu vida. La única forma de estar realmente satisfecho es hacer aquello que crees que es un buen trabajo, y la única forma de hacer un gran trabajo es amar aquello que haces”</p>
              </div>
          </div><!--row-->
        </div><!--inicio-->
      </div><!--container-fluid-->

      <?php require_once("footer.php");?>
     </div><!--container-fluid-->
    
</body>
</html>
<?php
}else{
  header("Location:".Conectar::ruta()."index.php");
}
?>


                            
                            <link href="https://snatchbot.me/sdk/webchat.css" rel="stylesheet" type="text/css"><script src="https://snatchbot.me/sdk/webchat.min.js"></script><script> Init('?botID=35420&appID=webchat', 600, 600, 'https://dvgpba5hywmpo.cloudfront.net/media/image/me7n0LoJRmAH6BNXUN6qiBjQU', 'bubble', '#00AFF0', 90, 90, 62.99999999999999, '', '1', '#FFFFFF', 0); /* for authentication of its users, you can define your userID (add &userID={login}) */ </script>
                        