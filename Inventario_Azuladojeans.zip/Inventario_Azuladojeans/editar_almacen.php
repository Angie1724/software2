<?php
 require_once("clases/confg.php");

  
   if(isset($_SESSION['backend_id'])){
     require_once("clases/proveedoresModulo.php");

     require_once("clases/almacenModulo.php");

   $proveedores=new Proveedores();

   $almacen=new Almacen();

   $proveedor=$proveedores->get_proveedores();
    $datos=$almacen->get_almacen_por_id($_GET["id_almacen"]);
    if(isset($_POST["grabar"]) and $_POST["grabar"]=="si"){
     
       require_once("clases/almacenModulo.php");
       $entrada=new Almacen();
       $entrada->editar_almacen();
       exit();
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Editar almacen</title>
  <link rel="stylesheet"  href="">
  <link rel="icon"  href="imagenesazulado/pantalones.ico">
	<?php require_once("head.php");?>
</head>

<body>
    
    <div class="container fluid">
    	 
    	<?php require_once("menu_principal.php");?>


    	  <div class="container-fluid">
    	  	  
    	  	  <div class="row">
    	  	  	  <div class="col-sm-3">
    	  	  	  	  
    	  	  	  	  <?php require_once("menu_lateral.php");?>
    	  	  	  </div>

    	  	  	  <div class="col-sm-8">
    	  	  	  	   
    	  	  	  	    <div class="panel-almacen">
		  	 		 	 <ol class="breadcrumb">
							  <li><a href="<?php echo Conectar::ruta();?>home.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Principal</a></li>
							  <li><a href="<?php echo Conectar::ruta();?>almacen.php"><span class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span> Almacen</a></li>
							  <li><a href="<?php echo Conectar::ruta();?>agregar_almacen.php"><span class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span> Nueva producto al almacen</a></li>
							  <li><a href="<?php echo Conectar::ruta()?>reporte_entrada.php"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Orden de Almacen</a></li>
							 
						</ol>
		  	 		 </div>



		  	 		 <?php
                     
                     if(isset($_GET["m"])){
                       
                       switch($_GET["m"]) {
                        
                        case "1";
                        ?>
                        <h2 class="holi">los campos estan vacios</h2>
                        <?php 
                        break;
                         case "2";
                        ?>
                        <h2 class="holi">se ha editado el producto al almacen</h2>
                        <?php 
                        break;
                      }
                     }
		  	 		 ?>


             <div class="panel-almacen">

		  	 		 <div class="panel panel-default">
		  	 		 	  
		  	 		 	  <div class="panel-heading">
		  	 		 	  	 <h3 class="panel-title"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Formulario de registro de producto en almacen</h3>
		  	 		 	  </div>

		  	 		 	  <div class="panel-body">
		  	 		 	  	  
		  	 		 	  	  <form action="" class="form-horizontal" method="post">
                      <form method="post" action="" class="form-horizontal">
                        
                     
		  	 		 	  	  	
                                 <div class="form-group">
                                 	<label for="" class="col-sm-2 control-label">Código Producto</label>
                                    <div class="col-sm-6">
                                     <input type="text" name="cod_material" class="form-control" placeholder="codigo_materia" value="<?php echo $datos[0]["cod_material"]; ?>">
                                    </div>
                                 </div>

                                    <div class="form-group">
                                 	<label for="" class="col-sm-2 control-label">Descripción Producto</label>
                                    <div class="col-sm-6">
                                   <input type="text" name="material" class="form-control" placeholder="descripcion_producto" value="<?php echo $datos[0]["material"]; ?>">
                                    </div>
                                 </div>

                                  <div class="form-group">
                                 	<label for="" class="col-sm-2 control-label">Precio Producto</label>
                                    <div class="col-sm-6">
                                     <input type="text" name="precio" class="form-control" placeholder="precio producto" value="<?php echo $datos[0]["precio"]; ?>">
                                    </div>
                                 </div>


                                  <div class="form-group">
                                 	<label for="" class="col-sm-2 control-label">Status Producto</label>
                                    <div class="col-sm-6">
                                     <select name="status_producto">
                                      <option value="0">SELECCIONE</option>
                                      <option value="activo"
                                      <?php

                                      if($datos[0]["status_material"]=="activo"){
                                       echo "selected='selected'";}?>>

                                      ACTIVO</option>
                                      <option value="inactivo"><?php

                                      if($datos[0]["status_material"]=="inactivo"){ echo "selected='selected'";}?>>INACTIVO</option>
                                    </select>
                                    </div>
                                 </div>


                                  <div class="form-group">
                                  <label for="" class="col-sm-2 control-label">Existencia Producto</label>
                                    <div class="col-sm-6">
                                     <input type="text" name="existencia" class="form-control" placeholder="existencia producto" value="<?php echo $datos[0]["existencia"]; ?>"> 
                                    </div>
                                 </div>

                                  <div class="form-group">
                                  <label for="" class="col-sm-2 control-label">Ubicacion Producto</label>
                                    <div class="col-sm-6">
                                     <input type="text" name="ubicacion_deposito" class="form-control" placeholder="ubicacion deposito" value="<?php echo $datos[0]["ubicacion_deposito"]; ?>">
                                    </div>
                                 </div>


                                  <div class="form-group">
                                  <label for="" class="col-sm-2 control-label">Proveedor Producto</label>
                                    <div class="col-sm-6">
                                     <select name="rif_producto"  id="">
                                      <option value="0">SELECCIONE</option>
                                      <?php
                                             
                                             for($i=0;$i<sizeof($proveedor);$i++){
                                             
                              if($datos[0]["rif_proveedor"]==$proveedor[0]["rif_proveedor"]){

                                                 ?>
                                          <option value="<?php echo $proveedor[$i]["rif_proveedor"];?>" selected="selected"><?php echo $proveedor[$i]["nombre_proveedor"];?></option>
                                                 <?php



                                             } else{


                                              ?>
                                          <option value="<?php echo $proveedor[$i]["rif_proveedor"];?>"><?php echo $proveedor[$i]["nombre_proveedor"];?></option>
                                                 <?php

                                             }



                                             }
                                           ?>
                                    </select>
                                    </div>
                                 </div>

                                   <input type="hidden" name="grabar" value="si">

                                 <button type="submit" class="btn btn-default col-sm-offset-2">REGISTRAR</button>

                           </form>
                    </div>
              </div>
        </div>
  </div>

                       
                                      


                                          
	  <?php require_once("footer.php");?>
</body>
</html>

<?php } else {
	 header("Location:".Conectar::ruta()."index.php");
}?>