
 
   <!--<link href="css/bootstrap-responsive.css" rel="stylesheet">-->

<link href="<?php echo Conectar::ruta();?>public/js_tabla/jquery.dataTables.css" rel="stylesheet">