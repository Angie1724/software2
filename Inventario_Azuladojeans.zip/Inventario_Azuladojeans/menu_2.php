<!-- se crea un menu de lista ordenada-->
<!--se crea clase menu izq-->
<ul class="nav nav-pills nav-stacked menu_izquierdo">
<li class="btn btn-default">Menu</li>
<li role="presentation" class="">
	<a class="btn btn-primary ajax-link" href="<?php echo Conectar::ruta();?>home.php"> <span class="glyphicon glyphicon-home" aria-hidden="true">
		

	</span> Inicio 
</a>
</li>
<!--btn primary crear el boton-->
<li role="presentation" class=""> 
	<a class="btn btn-primary ajax-link" href="<?php echo Conectar::ruta();?>clientes.php"> 
		<span class="glyphicon glyphicon-user" aria-hidden="true">
			
		</span> Clientes
	</a>
</li>
<li role="presentation" class="">
	<a class="btn btn-primary ajax-link" href="<?php echo Conectar::ruta();?>proveedores.php">
		<span class="glyphicon glyphicon-user" aria-hidden="true">
			
		</span> Proveedores
	</a>
</li>
<li role="presentation" class="">
	<a class="btn btn-primary ajax-link" href="<?php echo Conectar::ruta();?>entradas.php">
		<span class="glyphicon glyphicon-shopping-cart" aria-hidden="true">
			
		</span>Entradas
	</a>
</li>
<li role="presentation" class="">
	<a class="btn btn-primary ajax-link" href="<?php echo Conectar::ruta();?>almacen.php">
		<span class="glyphicon glyphicon-tasks" aria-hidden="true">
			
		</span> Almacen
	</a>
</li>
<li role="presentation" class="">
	<a class="btn btn-primary ajax-link" href="<?php echo Conectar::ruta();?>ventas.php">
		<span class="glyphicon glyphicon-lock" aria-hidden="true">
			
		</span> Ventas
	</a>
</li>
<li role="presentation" class="">
	<a class="btn btn-primary ajax-link" href="usuarios.php">
		<span class="glyphicon glyphicon-user" aria-hidden="true">
			
		</span> Usuarios
	</a>
</li>
<li role="presentation" class="">
	<a class="btn btn-primary ajax-link" href="<?php echo Conectar::ruta();?>multimedia.php">
		<span class=" glyphicon glyphicon-file" aria-hidden="true">
			
		</span> Multimedia
	</a>
</li>

<li role="presentation" class="">
	<a class="btn btn-primary ajax-link" href="logout.php">
		<span class="glyphicon glyphicon-off" aria-hidden="true">
			
		</span> Cerrar Sesión
	</a>
</li>

</ul>