<?php
   require_once("clases/confg.php");
   if(isset($_SESSION['backend_id'])){
      require_once("clases/usuarioModulo.php");
      $usuario=new Usuarios();
      $usuario->eliminar_usuario($_GET["id_usuario"]);
      header("Location:".Conectar::ruta()."usuarios.php");
      exit(); 
   
   } else{
   	  header("Location:".Conectar::ruta()."index.php");
   } 
 ?>