<?php
 require_once("clases/confg.php");

  
   if(isset($_SESSION['backend_id'])){
     require_once("clases/proveedoresModulo.php");
   $proveedores=new Proveedores();
   $proveedor=$proveedores->get_proveedores();
    if(isset($_POST["grabar"]) and $_POST["grabar"]=="si"){
     
       require_once("clases/almacenModulo.php");
       $entrada=new Almacen();
       $entrada->agregar_almacen();
       exit();
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Agregar almacen</title>
  <link rel="stylesheet"  href="">
  <link rel="icon"  href="imagenesazulado/pantalones.ico">
	<?php require_once("head.php");?>
</head>

<body>
    
    <div class="container fluid">
    	 
    	<?php require_once("menu_principal.php");?>


    	  <div class="container-fluid">
    	  	  
    	  	  <div class="row">
    	  	  	  <div class="col-sm-3">
    	  	  	  	  
    	  	  	  	  <?php require_once("menu_lateral.php");?>
    	  	  	  </div>

    	  	  	  <div class="col-sm-8">
    	  	  	  	   
    	  	  	  	    <div class="panel-almacen">
		  	 		 	 <ol class="breadcrumb">
							  <li><a href="<?php echo Conectar::ruta();?>home.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Principal</a></li>
							  <li><a href="<?php echo Conectar::ruta();?>almacen.php"><span class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span> Almacen</a></li>
							  <li><a href="<?php echo Conectar::ruta();?>agregar_almacen.php"><span class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span> Nuevo producto al almacen</a></li>
							  <li><a href="<?php echo Conectar::ruta()?>reporte_entrada.php"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Orden de Entrada</a></li>
							 
						</ol>
		  	 		 </div>



		  	 		 <?php
                     
                     if(isset($_GET["m"])){
                       
                       switch($_GET["m"]) {
                        
                        case "1";
                        ?>
                        <h2 class="holi">los campos estan vacios</h2>
                        <?php 
                        break;
                         case "2";
                        ?>
                        <h2 class="holi">se ha agregado la entrada</h2>
                        <?php 
                        break;
                      }
                     }
		  	 		 ?>


             <div class="panel-almacen">

		  	 		 <div class="panel panel-default">
		  	 		 	  
		  	 		 	  <div class="panel-heading">
		  	 		 	  	 <h3 class="panel-title"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Formulario de registro de producto en almacen</h3>
		  	 		 	  </div>

		  	 		 	  <div class="panel-body">
		  	 		 	  	  
		  	 		 	  	  <form action="" class="form-horizontal" method="post">
                      <form method="post" action="" class="form-horizontal">
                        
                     
		  	 		 	  	  	
                                 <div class="form-group">
                                 	<label for="" class="col-sm-2 control-label">Código Producto</label>
                                    <div class="col-sm-6">
                                     <input type="text" name="cod_producto" class="form-control" placeholder="codigo producto">
                                    </div>
                                 </div>

                                    <div class="form-group">
                                 	<label for="" class="col-sm-2 control-label">Descripción Producto</label>
                                    <div class="col-sm-6">
                                     <input type="text" name="descripcion_producto" class="form-control" placeholder="descripcion producto">
                                    </div>
                                 </div>

                                  <div class="form-group">
                                 	<label for="" class="col-sm-2 control-label">Precio Producto</label>
                                    <div class="col-sm-6">
                                     <input type="text" name="precio_producto" class="form-control" placeholder="precio producto">
                                    </div>
                                 </div>


                                  <div class="form-group">
                                 	<label for="" class="col-sm-2 control-label">Status Producto</label>
                                    <div class="col-sm-6">
                                     <select name="status_producto">
                                      <option value="0">SELECCIONE</option>
                                      <option value="ACTIVO">ACTIVO</option>
                                      <option value="INACTIVO">INACTIVO</option>
                                    </select>
                                    </div>
                                 </div>


                                  <div class="form-group">
                                  <label for="" class="col-sm-2 control-label">Existencia Producto</label>
                                    <div class="col-sm-6">
                                     <input type="text" name="existencia_producto" class="form-control" placeholder="existencia producto">
                                    </div>
                                 </div>

                                  <div class="form-group">
                                  <label for="" class="col-sm-2 control-label">Ubicacion Producto</label>
                                    <div class="col-sm-6">
                                     <input type="text" name="ubicacion_producto" class="form-control" placeholder="ubicacion producto">
                                    </div>
                                 </div>


                                  <div class="form-group">
                                  <label for="" class="col-sm-2 control-label">Proveedor Producto</label>
                                    <div class="col-sm-6">
                                     <select name="proveedor_producto"  id="">
                                      <option value="0">SELECCIONE</option>
                                      <?php
                                             
                                             for($i=0;$i<sizeof($proveedor);$i++){
                                                 
                                                 ?>
                                                <option value="<?php echo $proveedor[$i]["rif_proveedor"];?>"><?php echo $proveedor[$i]["nombre_proveedor"];?></option>
                                                 <?php
                                             }
                                           ?>
                                    </select>
                                    </div>
                                 </div>

                                   <input type="hidden" name="grabar" value="si">

                                 <input type="hidden" name="id" value="<?php echo $_GET["id_almacen"];?>">

                                 <button type="submit" class="btn btn-default col-sm-offset-2">REGISTRAR</button>

                           </form>
                    </div>
              </div>
        </div>
  </div>

                       
                                      


                                          
	  <?php require_once("footer.php");?>
</body>
</html>

<?php } else {
	 header("Location:".Conectar::ruta()."index.php");
}?>