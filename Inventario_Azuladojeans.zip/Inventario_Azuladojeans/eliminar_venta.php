<?php
 require_once("clases/confg.php");
   if(isset($_SESSION['backend_id'])){
   	  require_once("clases/ventasModulo.php");
   	  $venta= new Ventas();
   	  $venta->eliminar_venta($_GET["id_venta"]);
   	  header("Location:".Conectar::ruta()."ventas.php");
      exit();
   
   } else {
   	   header("Location:".Conectar::ruta()."index.php");
   	   exit();
   }
?>