<?php
 require_once("clases/confg.php");
   if(isset($_SESSION['backend_id'])){
   	  require_once("clases/entradasModulo.php");
   	  $entrada= new Entradas();
   	  $entrada->eliminar_entrada($_GET["id_entrada"]);
   	  header("Location:".Conectar::ruta()."entradas.php");
      exit();
   
   } else {
   	   header("Location:".Conectar::ruta()."index.php");
   	   exit();
   }
?>