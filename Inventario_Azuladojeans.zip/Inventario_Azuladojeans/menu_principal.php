<!--menu principal despues de index-->
  <nav class="navbar navbar-default">
   
   <!--clase contenedor menu principal donde va estar toda la informacion-->   
  <div class="container-fluid navbar_menu contenedor-menu-principal">
    <!-- Marca y conmutador se agrupan para una mejor visualización móvil -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">CONTROL DE INVENTARIOS</a>
    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Buscar">
        </div>
        <button type="submit" class="btn btn-default">Buscar</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
       
        <li class="dropdown navbar_dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
            <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Bienvenido ADMINISTRADOR 
            <span class="caret"></span>
          </a>
          <ul class="dropdown-menu" role="menu">
            <li>
              <a href="#">
                <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Mi Perfil
              </a>
            </li>
            <li class="divider"></li>
            <li>
              <a href="<?php echo Conectar::ruta();?>logout.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span> Cerrar Sesión
              </a>
            </li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>