<?php
   require_once("clases/confg.php");
   if(isset($_SESSION['backend_id'])){
       require_once("clases/proveedoresModulo.php");
       $pedido=new Proveedores();
       $pedido->eliminar_pedido($_GET["id_pedido"]);
       header("Location:".Conectar::ruta()."pedidos.php");
       exit();
   
   } else {
   	  header("Location:".Conectar::ruta()."index.php");
   	  exit();
   }
?>