<?php
 require_once("clases/confg.php");
   if(isset($_SESSION['backend_id'])){
   	  require_once("clases/almacenModulo.php");
   	  $almacen= new Almacen();
   	  $almacen->eliminar_almacen($_GET["id_almacen"]);
   	  header("Location:".Conectar::ruta()."almacen.php");
      exit();
   
   } else {
   	   header("Location:".Conectar::ruta()."index.php");
   	   exit();
   }
?>