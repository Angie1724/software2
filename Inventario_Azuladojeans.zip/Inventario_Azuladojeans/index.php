﻿<?php

require_once("clases/confg.php");
require_once("clases/usuariomodulo.php");

$usuario= new Usuarios();

if (isset($_POST["grabar"]) and $_POST["grabar"]=="si") {
	$usuario->login();
	exit();
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>BIENVENIDO A AZULADO JEANS</title>
	<link rel="stylesheet"  href="">
	<link rel="icon"  href="imagenesazulado/pantalones.ico">
	<?php
	require_once("head.php");
	?>
</head>
<body class="pagina_index">
	<div class="container-fluid">
		<div class="container">
			<div class="row">
				
					<center>
					<h2>SISTEMA DE CONTROL DE INVENTARIO Y VENTAS</h2>
				
					<h3>AZULADO JEANS</h3>
					</center>
				
			</div><!--row-->
		</div><!--container-->
		<div class="container">
			<div class="row">
				<div class="col-sm-5 col-sm-offset-3"> <!--Col sm  tamaño espacio de trabajo-->
					<form method="post" action="">
						<div class="form-group">
							<label for="">Usuario</label>
							<input type="text" name="usuario" class="form-control" placeholder="Usuario">
						</div>
						<div class="form-group">
							<label for="">Contraseña</label>
							<input type="text" name="contraseña" class="form-control" placeholder="Contraseña">
						</div>

						<input type="hidden" name="grabar" value="si">

						<center>
							<button type="submit" class="btn btn-default">INGRESAR
						</center>
						</button>
					</form>
				</div>
			</div>
		</div>
	</div><!--container-fluid-->

</body>
</html>