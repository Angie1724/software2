<footer class="footer">
	
   <p class="pull-left"><a href="">AZULADO JEANS</a> <?php echo date("Y")?>
   </p>
   <p class="pull-right"><a href="">SIMBOLO DE ELEGANCIA</a>
   </p>

</footer>
<!--pie de pagina-->