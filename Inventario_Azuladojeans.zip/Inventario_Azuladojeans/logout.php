<?php

require_once("clases/confg.php");

session_destroy();
/*redireccione al index*/
 header("Location:".Conectar::ruta()."index.php");

?>
